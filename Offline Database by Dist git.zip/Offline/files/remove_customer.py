

def remove_customer():
    a_file = open("database.txt", "r")
    lines = a_file.readlines()
    a_file.close()

    x = int(input("What line you want to remove?: "))
    del lines[x]
    new_file = open("database.txt", "w+")
    for line in lines:
        new_file.write(line)
    new_file.close()
    print("You have removed: " + str(x))



