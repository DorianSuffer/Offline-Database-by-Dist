import os
import os.path


class Customer:
   def __init__(self, name, lastname, city, adress, adress_number, id_card):
      self.name = name
      self.lastname = lastname
      self.city = city
      self.adress = adress
      self.adress_number = adress_number
      self.id_card = id_card

while True:
    x = input("\nEnter a name: ")
    y = input("Enter a lastname: ")
    c = input("Enter a city: ")
    a = input("Enter an adress: ")
    an = input("Enter an adress number: ")
    idc = input("Enter an id card: ")
    print("")

    p = Customer(x, y, c, a, an, idc)
    table = ("\n[  " + p.name + " ] [ " + p.lastname + " ] [ " + p.city + " ] [ " + p.adress + " ] [ " + p.adress_number + " ] [ " + p.id_card + " ]\n")
    print(table)
    print("a customer has added!\n")

    text_file = open("database.txt", "a+")
    text_file.write(table)
    text_file.close()
    break








