from find import find
from remove_customer import remove_customer

def choice():
    while True:
        print("1. Add a customer.")
        print("2. Delete a customer.")
        print("3. Search a customer.")
        print("4. Exit.\n")
        x = input("What you want to do?: ")
        if x == '1':
            from add_customer import Customer
            choice()
        elif x == '2':
            remove_customer()
            choice()
        elif x == '3':
            find()
            choice()
        elif x == '4':
            quit()
            choice()
        else:
            print("\nwrong choice!\n you must to choose between 1-4.\n")
            choice()






    
