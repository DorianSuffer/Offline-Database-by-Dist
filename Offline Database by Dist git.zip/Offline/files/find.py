# the script to find interesting information from database.txt

def find():
    a_file = open("database.txt")
    x = input("What you want to find: ")
    for line in a_file:
        if x in line:
            print(line)	
    a_file.close()





