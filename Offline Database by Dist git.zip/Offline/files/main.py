from choice import choice
from find import find
from remove_customer import remove_customer

#introduce
print("Offline Database by Dist-\n")

#main loop

def main_loop():
	while True:
		choice()
main_loop()
